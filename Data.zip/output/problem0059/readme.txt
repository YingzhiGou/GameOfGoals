Language Size: 6
Number of Condition-Action rules: 4
Effect size: 1
Number of Rules in KB: 3
Size of KB rule: 2
Generation Time: 29ms