Language Size: 4
Number of Condition-Action rules: 2
Effect size: 1
Number of Rules in KB: 2
Size of KB rule: 2
Generation Time: 53ms