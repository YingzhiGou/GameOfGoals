Language Size: 2
Number of Condition-Action rules: 8
Effect size: 1
Number of Rules in KB: 1
Size of KB rule: 2
Generation Time: 14ms